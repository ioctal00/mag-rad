# Database Sweep Index

`query_runs.csv` is the sweep manifest fact table. `execution_features.csv` is the consolidated query-run feature table copied from each nested query-sweep `_index`, with `database_sweep_id`, `dataset_id`, `runtime_config_id`, and `query_sweep_id` attached.

`dataset_capability_audits.csv` is one row per dataset load. It summarizes row counts, tenant skew, hot tenant shares and declared vs measured dataset capabilities from `dataset-loads/<load-id>/`. `dataset_parameter_values_file` points to the tenant/hot-tenant parameter pool that workload instances can use without hand-picking values.

`feature_overview.csv` is a compact human QA table. It intentionally omits long paths, JSON blobs and fingerprints; use it for quick reading, not as the canonical source of truth. Blank numeric cells in this file mean missing or not-applicable, not zero. Use the `*_available`, `*_applicable`, and `overview_missing_reason` columns to distinguish expected blanks from collection problems.

Use `plan_structure_features.csv` for one-row-per-query-run plan structure features. Use `plan_nodes.csv` and `plan_edges.csv` when the plan tree must be reconstructed. `region_fragments.csv` and `worker_task_fragments.csv` are child evidence tables for N+1 GAC/FDW plans; they may have many rows per query run and must be aggregated back through `remote_region_*` and `worker_task_*` features before clustering. Join by `query_run_id` for query-level tables, and by `database_sweep_id` plus `node_name` for static hardware context in `hardware_nodes.csv`.
