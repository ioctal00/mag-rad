DROP SCHEMA IF EXISTS stats_us CASCADE;
CREATE SCHEMA stats_us;

IMPORT FOREIGN SCHEMA stats
  FROM SERVER us_citus
  INTO stats_us;
DO $audit$
BEGIN
  IF (
    SELECT count(*)
    FROM information_schema.foreign_tables
    WHERE foreign_table_schema = 'stats_us'
  ) <> 8 THEN
    RAISE EXCEPTION 'Expected eight STATS foreign tables in stats_us';
  END IF;
END
$audit$;
