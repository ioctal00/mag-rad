DROP SCHEMA IF EXISTS stats_eu CASCADE;
CREATE SCHEMA stats_eu;

IMPORT FOREIGN SCHEMA stats
  FROM SERVER eu_citus
  INTO stats_eu;
DO $audit$
BEGIN
  IF (
    SELECT count(*)
    FROM information_schema.foreign_tables
    WHERE foreign_table_schema = 'stats_eu'
  ) <> 8 THEN
    RAISE EXCEPTION 'Expected eight STATS foreign tables in stats_eu';
  END IF;
END
$audit$;
